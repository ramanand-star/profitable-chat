import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chart-patterns',
  templateUrl: './chart-patterns.page.html',
  styleUrls: ['./chart-patterns.page.scss'],
})
export class ChartPatternsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
