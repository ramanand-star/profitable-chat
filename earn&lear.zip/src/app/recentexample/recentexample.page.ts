import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-recentexample',
  templateUrl: './recentexample.page.html',
  styleUrls: ['./recentexample.page.scss'],
})
export class RecentexamplePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
