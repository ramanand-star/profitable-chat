import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-get-more',
  templateUrl: './get-more.page.html',
  styleUrls: ['./get-more.page.scss'],
})
export class GetMorePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
