import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-patternlearing',
  templateUrl: './patternlearing.page.html',
  styleUrls: ['./patternlearing.page.scss'],
})
export class PatternlearingPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
